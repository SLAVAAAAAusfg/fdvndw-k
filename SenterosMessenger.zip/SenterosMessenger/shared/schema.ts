import { pgTable, text, serial, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Chat schema
export const chats = pgTable("chats", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  pinnedMessageId: serial("pinned_message_id").notNull().default(0),
});

export const insertChatSchema = createInsertSchema(chats).pick({
  name: true,
  pinnedMessageId: true,
});

// Message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  chatId: serial("chat_id").notNull().references(() => chats.id),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  chatId: true,
  role: true,
  content: true,
});

// Settings schema
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  language: text("language").notNull().default("ru"),
  theme: text("theme").notNull().default("dark"),
});

export const insertSettingsSchema = createInsertSchema(settings).pick({
  language: true,
  theme: true,
});

// Types
export type Chat = typeof chats.$inferSelect;
export type InsertChat = z.infer<typeof insertChatSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

// Frontend types
export type ChatWithMessages = Chat & {
  messages: Message[];
};

export type MessageType = {
  id: string;
  role: string;
  content: string;
  timestamp?: number;
  imageUrl?: string; // URL изображения, если есть
};

export type ChatType = {
  id: string;
  name: string;
  messages: MessageType[];
  pinnedMessageId?: string | null;
};

export type SettingsType = {
  language: string;
  theme: string;
};
