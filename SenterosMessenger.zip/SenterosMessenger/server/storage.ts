import { 
  type Chat, type InsertChat, 
  type Message, type InsertMessage,
  type Settings, type InsertSettings,
  type ChatWithMessages, type MessageType, type ChatType,
  chats, messages, settings
} from "@shared/schema";
import { drizzle } from 'drizzle-orm/postgres-js';
import { eq, desc } from 'drizzle-orm';
import postgres from 'postgres';

// Interface for storage operations
export interface IStorage {
  // Chat operations
  getChats(): Promise<Chat[]>;
  getChatById(id: number): Promise<ChatWithMessages | undefined>;
  createChat(chat: InsertChat): Promise<Chat>;
  updateChat(id: number, chat: Partial<InsertChat>): Promise<Chat | undefined>;
  deleteChat(id: number): Promise<boolean>;
  
  // Message operations
  getMessages(chatId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Settings operations
  getSettings(): Promise<Settings>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
  
  // Database initialization
  initDb(): Promise<void>;
}

// PostgreSQL storage implementation
export class PostgresStorage implements IStorage {
  private client: postgres.Sql<{}>;
  private db: ReturnType<typeof drizzle>;
  
  constructor() {
    // Create PostgreSQL client
    this.client = postgres(process.env.DATABASE_URL!);
    this.db = drizzle(this.client);
  }
  
  async initDb(): Promise<void> {
    try {
      // Create tables if they don't exist
      await this.client.unsafe(`
        CREATE TABLE IF NOT EXISTS chats (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL,
          pinned_message_id INTEGER NOT NULL DEFAULT 0,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS messages (
          id SERIAL PRIMARY KEY,
          chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
          role TEXT NOT NULL,
          content TEXT NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS settings (
          id SERIAL PRIMARY KEY,
          language TEXT NOT NULL DEFAULT 'ru',
          theme TEXT NOT NULL DEFAULT 'dark',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
      
      // Check if settings exist, if not create default
      const existingSettings = await this.db.select().from(settings);
      if (existingSettings.length === 0) {
        await this.db.insert(settings).values({
          language: 'ru',
          theme: 'dark'
        });
      }
      
      // Check if there's at least one chat, if not create default
      const existingChats = await this.db.select().from(chats);
      if (existingChats.length === 0) {
        await this.createChat({ name: "SenterosAI" });
      }
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }
  
  // Chat operations
  async getChats(): Promise<Chat[]> {
    try {
      return await this.db.select().from(chats).orderBy(desc(chats.createdAt));
    } catch (error) {
      console.error('Error getting chats:', error);
      throw error;
    }
  }

  async getChatById(id: number): Promise<ChatWithMessages | undefined> {
    try {
      const chatResult = await this.db.select().from(chats).where(eq(chats.id, id));
      if (chatResult.length === 0) return undefined;
      
      const chat = chatResult[0];
      const chatMessages = await this.db.select()
        .from(messages)
        .where(eq(messages.chatId, id))
        .orderBy(messages.createdAt);
      
      return {
        ...chat,
        messages: chatMessages
      };
    } catch (error) {
      console.error(`Error getting chat by id ${id}:`, error);
      throw error;
    }
  }

  async createChat(chat: InsertChat): Promise<Chat> {
    try {
      const result = await this.db.insert(chats).values(chat).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating chat:', error);
      throw error;
    }
  }

  async updateChat(id: number, chatData: Partial<InsertChat>): Promise<Chat | undefined> {
    try {
      const result = await this.db.update(chats)
        .set(chatData)
        .where(eq(chats.id, id))
        .returning();
      
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error(`Error updating chat ${id}:`, error);
      throw error;
    }
  }

  async deleteChat(id: number): Promise<boolean> {
    try {
      const result = await this.db.delete(chats).where(eq(chats.id, id)).returning();
      return result.length > 0;
    } catch (error) {
      console.error(`Error deleting chat ${id}:`, error);
      throw error;
    }
  }

  // Message operations
  async getMessages(chatId: number): Promise<Message[]> {
    try {
      return await this.db.select()
        .from(messages)
        .where(eq(messages.chatId, chatId))
        .orderBy(messages.createdAt);
    } catch (error) {
      console.error(`Error getting messages for chat ${chatId}:`, error);
      throw error;
    }
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    try {
      const result = await this.db.insert(messages).values(message).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating message:', error);
      throw error;
    }
  }

  // Settings operations
  async getSettings(): Promise<Settings> {
    try {
      const result = await this.db.select().from(settings).limit(1);
      if (result.length === 0) {
        // Create default settings if none exist
        const defaultSettings = {
          language: 'ru',
          theme: 'dark'
        };
        const inserted = await this.db.insert(settings).values(defaultSettings).returning();
        return inserted[0];
      }
      return result[0];
    } catch (error) {
      console.error('Error getting settings:', error);
      throw error;
    }
  }

  async updateSettings(settingsData: Partial<InsertSettings>): Promise<Settings> {
    try {
      // Get existing settings
      const existingSettings = await this.getSettings();
      
      const result = await this.db.update(settings)
        .set(settingsData)
        .where(eq(settings.id, existingSettings.id))
        .returning();
      
      return result[0];
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  }
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private chats: Map<number, Chat>;
  private messages: Map<number, Message[]>;
  private userSettings: Settings;
  private chatCounter: number;
  private messageCounter: number;

  constructor() {
    this.chats = new Map();
    this.messages = new Map();
    this.chatCounter = 1;
    this.messageCounter = 1;
    
    // Default settings
    this.userSettings = {
      id: 1,
      language: "ru",
      theme: "dark"
    };
    
    // Create initial chat
    this.createChat({ name: "SenterosAI" });
  }
  
  async initDb(): Promise<void> {
    // No initialization needed for in-memory storage
    return Promise.resolve();
  }

  // Chat operations
  async getChats(): Promise<Chat[]> {
    return Array.from(this.chats.values());
  }

  async getChatById(id: number): Promise<ChatWithMessages | undefined> {
    const chat = this.chats.get(id);
    if (!chat) return undefined;

    const chatMessages = this.messages.get(id) || [];
    return {
      ...chat,
      messages: chatMessages
    };
  }

  async createChat(chat: InsertChat): Promise<Chat> {
    const id = this.chatCounter++;
    const newChat: Chat = {
      id,
      name: chat.name,
      createdAt: new Date(),
      pinnedMessageId: chat.pinnedMessageId || 0
    };
    
    this.chats.set(id, newChat);
    this.messages.set(id, []);
    
    return newChat;
  }

  async updateChat(id: number, chatData: Partial<InsertChat>): Promise<Chat | undefined> {
    const chat = this.chats.get(id);
    if (!chat) return undefined;

    const updatedChat: Chat = {
      ...chat,
      name: chatData.name !== undefined ? chatData.name : chat.name,
      pinnedMessageId: chatData.pinnedMessageId !== undefined ? chatData.pinnedMessageId : chat.pinnedMessageId
    };

    this.chats.set(id, updatedChat);
    return updatedChat;
  }

  async deleteChat(id: number): Promise<boolean> {
    const deleted = this.chats.delete(id);
    if (deleted) {
      this.messages.delete(id);
    }
    return deleted;
  }

  // Message operations
  async getMessages(chatId: number): Promise<Message[]> {
    return this.messages.get(chatId) || [];
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageCounter++;
    const newMessage: Message = {
      id,
      chatId: message.chatId!,
      role: message.role,
      content: message.content,
      createdAt: new Date()
    };

    const chatMessages = this.messages.get(message.chatId!) || [];
    chatMessages.push(newMessage);
    this.messages.set(message.chatId!, chatMessages);

    return newMessage;
  }

  // Settings operations
  async getSettings(): Promise<Settings> {
    return this.userSettings;
  }

  async updateSettings(settings: Partial<InsertSettings>): Promise<Settings> {
    this.userSettings = {
      ...this.userSettings,
      language: settings.language !== undefined ? settings.language : this.userSettings.language,
      theme: settings.theme !== undefined ? settings.theme : this.userSettings.theme
    };
    
    return this.userSettings;
  }
}

// Create singleton instance
// Use PostgreSQL storage in production, MemStorage for development
export const storage = process.env.DATABASE_URL 
  ? new PostgresStorage() 
  : new MemStorage();
