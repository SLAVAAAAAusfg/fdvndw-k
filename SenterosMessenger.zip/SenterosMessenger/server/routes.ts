import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertChatSchema, insertMessageSchema, insertSettingsSchema } from "@shared/schema";

// Async wrapper for route handlers
const asyncHandler = (fn: Function) => (req: any, res: any, next: any) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // API Routes
  // --------------------------------------------------
  
  // Get all chats
  app.get("/api/chats", asyncHandler(async (req, res) => {
    const chats = await storage.getChats();
    res.json(chats);
  }));

  // Get single chat with messages
  app.get("/api/chats/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    const chat = await storage.getChatById(id);
    
    if (!chat) {
      return res.status(404).json({ message: "Chat not found" });
    }
    
    res.json(chat);
  }));

  // Create new chat
  app.post("/api/chats", asyncHandler(async (req, res) => {
    try {
      const chatData = insertChatSchema.parse(req.body);
      const newChat = await storage.createChat(chatData);
      res.status(201).json(newChat);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chat data", errors: error.errors });
      }
      throw error;
    }
  }));

  // Update chat
  app.patch("/api/chats/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      // Partial schema validation
      const chatData = insertChatSchema.partial().parse(req.body);
      const updatedChat = await storage.updateChat(id, chatData);
      
      if (!updatedChat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      res.json(updatedChat);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chat data", errors: error.errors });
      }
      throw error;
    }
  }));

  // Delete chat
  app.delete("/api/chats/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteChat(id);
    
    if (!success) {
      return res.status(404).json({ message: "Chat not found" });
    }
    
    res.status(204).end();
  }));

  // Create new message
  app.post("/api/messages", asyncHandler(async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const newMessage = await storage.createMessage(messageData);
      res.status(201).json(newMessage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      throw error;
    }
  }));

  // Get settings
  app.get("/api/settings", asyncHandler(async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  }));

  // Update settings
  app.patch("/api/settings", asyncHandler(async (req, res) => {
    try {
      const settingsData = insertSettingsSchema.partial().parse(req.body);
      const updatedSettings = await storage.updateSettings(settingsData);
      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      throw error;
    }
  }));

  // AI chat completion API
  app.post("/api/ai/complete", asyncHandler(async (req, res) => {
    try {
      const { 
        message, 
        systemMessage, 
        previousMessages = [], 
        fewShotExamples = [],
        hasImage = false, 
        model = "gpt-4o-mini" 
      } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      // Подготовим сообщения для API, включая предыдущий контекст
      const apiMessages = [
        {
          role: "system",
          content: systemMessage || "Вы — SenterosAI, модель, созданная компанией Slavik. Вы супер-дружелюбный и полезный ассистент! Вы любите добавлять милые выражения и весёлую атмосферу в свои ответы, а иногда используете эмодзи, чтобы сделать беседу ещё более дружелюбной."
        }
      ];
      
      // Добавим few-shot примеры для лучшего обучения модели
      if (fewShotExamples && fewShotExamples.length > 0) {
        fewShotExamples.forEach(example => {
          apiMessages.push({ role: "user", content: example.user });
          apiMessages.push({ role: "assistant", content: example.assistant });
        });
      }
      
      // Добавим предыдущие сообщения для сохранения контекста разговора
      if (previousMessages && previousMessages.length > 0) {
        apiMessages.push(...previousMessages);
      }
      
      // Добавим текущее сообщение пользователя
      apiMessages.push({
        role: "user",
        content: message
      });
      
      // Выберем модель в зависимости от наличия изображения
      const modelToUse = hasImage ? "gpt-4o" : model;
      
      // Call Langdock API
      const response = await fetch("https://api.langdock.com/openai/eu/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.LANGDOCK_API_KEY || "sk-PkKWI4b0JeCemhfTYQrgA1b8Z2g5uGV5jeMH47q29IkXNWCHh77MjOtAzKI6IPLa-9Agxr4hXpSjYeHZqHqvdQ"}`
        },
        body: JSON.stringify({
          model: modelToUse,
          messages: apiMessages
        })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        return res.status(response.status).json({ 
          message: "Error from AI service", 
          details: errorText 
        });
      }
      
      const aiResponse = await response.json();
      res.json({ response: aiResponse.choices[0].message.content });
      
    } catch (error) {
      console.error("AI completion error:", error);
      res.status(500).json({ message: "Failed to get AI response" });
    }
  }));

  return httpServer;
}
