import React, { useEffect } from 'react';
import { SettingsType } from '@shared/schema';
import { getTranslation } from '../utils/languageUtils';

interface ChatSettingsProps {
  isOpen: boolean;
  settings: SettingsType;
  onClose: () => void;
  onUpdateSettings: (settings: SettingsType) => void;
}

const ChatSettings: React.FC<ChatSettingsProps> = ({
  isOpen,
  settings,
  onClose,
  onUpdateSettings
}) => {
  const panelClass = `absolute top-0 right-0 h-full w-80 bg-background border-l border-muted transform ${
    isOpen ? 'translate-x-0' : 'translate-x-full'
  } transition-transform duration-300 z-20`;

  // Apply theme to the document body
  useEffect(() => {
    if (settings.theme === 'light') {
      document.documentElement.classList.add('light-theme');
      document.documentElement.classList.remove('dark-theme');
    } else {
      document.documentElement.classList.add('dark-theme');
      document.documentElement.classList.remove('light-theme');
    }
  }, [settings.theme]);

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onUpdateSettings({
      ...settings,
      language: e.target.value
    });
  };

  const handleThemeToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateSettings({
      ...settings,
      theme: e.target.checked ? 'dark' : 'light'
    });
  };

  // Close settings panel when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isOpen && window.innerWidth < 768) {
        const target = event.target as HTMLElement;
        if (!target.closest('.settings-panel')) {
          onClose();
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  return (
    <div className={`settings-panel ${panelClass}`}>
      <div className="p-4 border-b border-muted flex items-center justify-between">
        <h2 className="font-semibold text-lg">
          {getTranslation(settings.language, 'settings')}
        </h2>
        <button 
          onClick={onClose}
          className="p-1 text-muted-foreground hover:text-white"
          aria-label="Close settings"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
      
      <div className="p-4">
        <div className="mb-6">
          <h3 className="text-sm font-medium mb-2 text-muted-foreground">
            {getTranslation(settings.language, 'theme')}
          </h3>
          <div className="flex items-center justify-between">
            <span>{getTranslation(settings.language, 'darkTheme')}</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                className="sr-only peer"
                checked={settings.theme === 'dark'}
                onChange={handleThemeToggle}
              />
              <div className="w-11 h-6 bg-secondary rounded-full peer-focus:ring-1 peer-focus:ring-primary after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-5 peer-checked:bg-primary"></div>
            </label>
          </div>
        </div>
        
        <div className="mb-6">
          <h3 className="text-sm font-medium mb-2 text-muted-foreground">
            {getTranslation(settings.language, 'language')}
          </h3>
          <select 
            value={settings.language}
            onChange={handleLanguageChange}
            className="w-full bg-secondary border border-muted rounded p-2 text-white focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="ru">Русский</option>
            <option value="en">English</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default ChatSettings;
