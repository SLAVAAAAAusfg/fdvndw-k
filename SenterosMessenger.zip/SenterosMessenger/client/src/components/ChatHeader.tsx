import React, { useState, useRef, useEffect } from 'react';
import { ChatType } from '@shared/schema';
import { getTranslation } from '../utils/languageUtils';
import SenterosLogo from './SenterosLogo';
import { useToast } from '@/hooks/use-toast';

interface ChatHeaderProps {
  currentChat: ChatType | null;
  chats: ChatType[];
  toggleSidebar: () => void;
  toggleSettings: () => void;
  createNewChat: () => void;
  onChangeChat: (chatId: string) => void;
  onRenameChat: (chatId: string) => void;
  onDeleteChat: (chatId: string) => void;
  language: string;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({ 
  currentChat, 
  chats,
  toggleSidebar, 
  toggleSettings, 
  createNewChat,
  onChangeChat,
  onRenameChat,
  onDeleteChat,
  language
}) => {
  const [showChatDropdown, setShowChatDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowChatDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Функция для отображения сообщения "Скоро будет"
  const showComingSoon = () => {
    toast({
      title: getTranslation(language, 'comingSoon'),
      description: getTranslation(language, 'featureComingSoon'),
      duration: 3000
    });
  };

  // Сортируем чаты так, чтобы последний был вверху
  const sortedChats = [...chats].sort((a, b) => {
    if (a.id === currentChat?.id) return -1;
    if (b.id === currentChat?.id) return 1;
    return 0;
  });

  return (
    <header className="border-b border-muted py-3 px-4 flex items-center justify-between header-gradient">
      <div className="flex items-center">
        <button 
          onClick={toggleSidebar} 
          className="p-2 text-muted-foreground hover:bg-secondary rounded mr-2 md:mr-0"
          aria-label="Toggle sidebar"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
          </svg>
        </button>

        <div className="hidden md:flex ml-4">
          <SenterosLogo />
        </div>

        {/* Chat selector (disabled) */}
        <div className="relative ml-4 hidden" ref={dropdownRef}>
          <div 
            className="flex items-center bg-background border border-muted rounded-full px-4 py-1.5 opacity-50 cursor-not-allowed button-gradient"
            aria-label="Chat selector"
          >
            <div className="w-6 h-6 senteros-avatar mr-2">
              <img 
                src="https://i.ibb.co/xKtY6RXz/Chat-GPT-Image-1-2025-17-16-51.png" 
                alt="S" 
                className="w-full h-full"
              />
            </div>
            <span>{currentChat?.name || getTranslation(language, 'newChat')}</span>
          </div>


        </div>
      </div>

      <div className="flex items-center">
        <button 
          onClick={toggleSettings} 
          className="p-2 text-muted-foreground hover:bg-secondary rounded mr-2"
          aria-label="Settings"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
          </svg>
        </button>

        <button 
          onClick={showComingSoon}
          className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-muted-foreground" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
    </header>
  );
};

export default ChatHeader;