import React, { useState } from 'react';
import { getTranslation } from '../utils/languageUtils';

interface RenameModalProps {
  chatId: string;
  initialName: string;
  isOpen: boolean;
  language: string;
  onClose: () => void;
  onRename: (chatId: string, newName: string) => void;
}

const RenameModal: React.FC<RenameModalProps> = ({
  chatId,
  initialName,
  isOpen,
  language,
  onClose,
  onRename
}) => {
  const [newName, setNewName] = useState(initialName);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      onRename(chatId, newName);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-background border border-muted rounded-lg p-4 w-80">
        <h3 className="text-lg font-semibold mb-4">
          {getTranslation(language, 'rename')}
        </h3>
        
        <form onSubmit={handleSubmit}>
          <input 
            type="text" 
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            className="w-full bg-secondary border border-muted rounded p-2 mb-4 text-white focus:outline-none focus:ring-1 focus:ring-primary"
            placeholder={language === 'en' ? 'Chat name' : 'Название чата'}
            autoFocus
          />
          
          <div className="flex justify-end space-x-2">
            <button 
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-muted-foreground hover:text-white"
            >
              {getTranslation(language, 'cancel')}
            </button>
            
            <button 
              type="submit"
              className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-80"
              disabled={!newName.trim()}
            >
              {getTranslation(language, 'save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RenameModal;
