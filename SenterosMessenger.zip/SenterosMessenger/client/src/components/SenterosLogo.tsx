import React from 'react';

const SenterosLogo: React.FC = () => {
  return (
    <div className="flex items-center justify-center">
      <div className="w-8 h-8 rounded-full flex items-center justify-center">
        <img 
          src="https://i.ibb.co/xKtY6RXz/Chat-GPT-Image-1-2025-17-16-51.png" 
          alt="SenterosAI Logo" 
          className="w-full h-full object-cover rounded-full"
        />
      </div>
      <span className="ml-2 font-semibold">SenterosAI</span>
    </div>
  );
};

export default SenterosLogo;