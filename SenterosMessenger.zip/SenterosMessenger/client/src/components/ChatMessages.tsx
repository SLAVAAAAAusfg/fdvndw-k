import React, { useEffect, useRef, useState } from 'react';
import { ChatType, MessageType } from '@shared/schema';
import { getTranslation } from '../utils/languageUtils';
import { renderMarkdown } from '../utils/markdownUtils';
import SenterosLogo from './SenterosLogo';

interface ChatMessagesProps {
  chat: ChatType | null;
  pinnedMessage: MessageType | null | undefined;
  language: string;
  onPinMessage: (messageId: string) => void;
  onRegenerateResponse: (messageId: string) => void;
}

interface MessageWithTypingState extends MessageType {
  isTyping?: boolean;
  displayedContent?: string;
}

const ChatMessages: React.FC<ChatMessagesProps> = ({
  chat,
  pinnedMessage,
  language,
  onPinMessage,
  onRegenerateResponse
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [displayMessages, setDisplayMessages] = useState<MessageWithTypingState[]>([]);
  const [likedMessages, setLikedMessages] = useState<Record<string, 'liked' | 'disliked' | null>>({});

  // Process messages and handle typing animation
  useEffect(() => {
    if (!chat || !chat.messages.length) {
      setDisplayMessages([]);
      return;
    }

    // Get the last message
    const lastMessage = chat.messages[chat.messages.length - 1];
    
    // Only animate new messages, not existing ones on page reload
    const isNewMessage = !displayMessages.some(m => m.id === lastMessage.id);
    if (lastMessage.role === 'assistant' && isNewMessage) {
      
      // Add all previous messages normally
      const previousMessages = chat.messages.slice(0, -1);
      const updatedMessages = [
        ...previousMessages.map(m => ({ ...m })),
        { ...lastMessage, isTyping: true, displayedContent: '' }
      ];
      
      setDisplayMessages(updatedMessages);
      
      // Animate the typing for the last message
      let index = 0;
      const interval = setInterval(() => {
        if (index <= lastMessage.content.length) {
          setDisplayMessages(prevMessages => {
            const updatedMessages = [...prevMessages];
            updatedMessages[updatedMessages.length - 1] = {
              ...updatedMessages[updatedMessages.length - 1],
              displayedContent: lastMessage.content.substring(0, index)
            };
            return updatedMessages;
          });
          index++;
        } else {
          // Animation finished
          setDisplayMessages(prevMessages => {
            const updatedMessages = [...prevMessages];
            updatedMessages[updatedMessages.length - 1] = {
              ...updatedMessages[updatedMessages.length - 1],
              isTyping: false,
              displayedContent: lastMessage.content
            };
            return updatedMessages;
          });
          clearInterval(interval);
        }
      }, 20); // Adjust the speed of typing here
      
      return () => clearInterval(interval);
    } else if (lastMessage.role !== 'assistant') {
      // If it's a user message or not a new message, just update normally
      setDisplayMessages(chat.messages.map(m => ({ ...m })));
    }
  }, [chat?.messages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [displayMessages]);

  // Copy message to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        // Could show a toast here
      })
      .catch(err => {
        console.error('Failed to copy text: ', err);
      });
  };

  // Handle like/dislike
  const handleRating = (messageId: string, rating: 'liked' | 'disliked') => {
    setLikedMessages(prev => {
      const current = prev[messageId];
      // Toggle if same rating is clicked
      if (current === rating) {
        return { ...prev, [messageId]: null };
      }
      return { ...prev, [messageId]: rating };
    });
  };

  // AI Avatar component
  const AIAvatar = () => (
    <div className="w-8 h-8 senteros-avatar mr-3 flex-shrink-0">
      <img 
        src="https://i.ibb.co/xKtY6RXz/Chat-GPT-Image-1-2025-17-16-51.png" 
        alt="Senteros AI"
        className="w-full h-full"
      />
    </div>
  );
  
  // Custom markdown content component
  const MarkdownContent = ({ content }: { content: string }) => {
    return (
      <div 
        className="markdown-content"
        dangerouslySetInnerHTML={{ __html: renderMarkdown(content) }}
      />
    );
  };

  // Empty state when no messages
  if (!chat || chat.messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="mb-4">
          <SenterosLogo />
        </div>
        <p className="text-muted-foreground text-center max-w-md mt-4">
          {getTranslation(language, 'emptyStateText')}
        </p>
      </div>
    );
  }

  return (
    <>
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 scrollbar-hide w-full"
      >
        {displayMessages.map((message, index) => (
          <div 
            key={message.id} 
            className={`message ${message.role === 'user' ? 'user-message' : 'ai-message'} mb-6 fade-in`}
          >
            {message.role === 'user' ? (
              // User message
              <div className="flex justify-end w-full">
                <div className="max-w-3xl text-right">
                  <div className="inline-block message-gradient-user text-white px-4 py-2 rounded-lg">
                    {message.imageUrl && (
                      <div className="mb-2">
                        <img 
                          src={message.imageUrl} 
                          alt="Attached" 
                          className="max-w-sm max-h-60 rounded-lg"
                          style={{ display: 'inline-block' }}
                        />
                      </div>
                    )}
                    {message.content && <p className="whitespace-pre-wrap">{message.content}</p>}
                    {!message.content && message.imageUrl && <p>{language === 'en' ? 'Image' : 'Изображение'}</p>}
                  </div>
                </div>
              </div>
            ) : (
              // AI message
              <div className="flex items-start w-full max-w-full">
                <div className="flex items-start w-full max-w-full">
                  <AIAvatar />
                  <div className="flex-1 max-w-full overflow-hidden">
                    <div className="message-gradient-ai p-4 rounded-lg text-foreground max-w-full relative">
                      {/* Action buttons positioned closer to content */}
                      <div className="absolute right-0 -top-7 flex items-center space-x-1 bg-background/50 rounded-md px-1 py-0.5 backdrop-blur-sm">
                        <button 
                          className="p-1 text-muted-foreground hover:text-foreground" 
                          title={getTranslation(language, 'copy')}
                          onClick={() => copyToClipboard(message.content)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z" />
                            <path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z" />
                          </svg>
                        </button>
                        <button 
                          className={`p-1 ${likedMessages[message.id] === 'liked' ? 'text-green-500' : 'text-muted-foreground hover:text-foreground'}`} 
                          title={getTranslation(language, 'like')}
                          onClick={() => handleRating(message.id, 'liked')}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
                          </svg>
                        </button>
                        <button 
                          className={`p-1 ${likedMessages[message.id] === 'disliked' ? 'text-destructive' : 'text-muted-foreground hover:text-foreground'}`} 
                          title={getTranslation(language, 'dislike')}
                          onClick={() => handleRating(message.id, 'disliked')}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M18 9.5a1.5 1.5 0 11-3 0v-6a1.5 1.5 0 013 0v6zM14 9.667v-5.43a2 2 0 00-1.105-1.79l-.05-.025A4 4 0 0011.055 2H5.64a2 2 0 00-1.962 1.608l-1.2 6A2 2 0 004.44 12H8v4a2 2 0 002 2 1 1 0 001-1v-.667a4 4 0 01.8-2.4l1.4-1.866a4 4 0 00.8-2.4z" />
                          </svg>
                        </button>
                        <button 
                          className="p-1 text-muted-foreground hover:text-primary" 
                          title={getTranslation(language, 'regenerate')}
                          onClick={() => onRegenerateResponse(message.id)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </div>
                      
                      {message.isTyping ? (
                        <div className="typing-animation markdown-content max-w-full">
                          {message.displayedContent || message.content}
                        </div>
                      ) : (
                        <MarkdownContent content={message.displayedContent || message.content} />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Pinned message */}
      {pinnedMessage && (
        <div className="border-t border-muted bg-background p-3">
          <div className="flex items-start">
            <div className="flex-1">
              <div className="flex items-center mb-1">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z" />
                </svg>
                <span className="text-xs text-muted-foreground">
                  {getTranslation(language, 'pinnedMessage')}
                </span>
              </div>
              <p className="text-sm truncate">{pinnedMessage.content}</p>
            </div>
            <button 
              className="p-1 text-muted-foreground hover:text-white"
              onClick={() => onPinMessage(pinnedMessage.id)}
              aria-label="Unpin message"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatMessages;