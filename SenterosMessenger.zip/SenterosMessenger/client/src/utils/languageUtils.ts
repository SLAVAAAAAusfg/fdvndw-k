// Language translations
export const translations = {
  ru: {
    newChat: 'Новый чат',
    askPlaceholder: 'Спросите SenterosAI...',
    chatHistory: 'История чатов',
    settings: 'Настройки',
    theme: 'Тема',
    darkTheme: 'Темная',
    lightTheme: 'Светлая',
    language: 'Язык',
    rename: 'Переименовать чат',
    cancel: 'Отмена',
    save: 'Сохранить',
    pinnedMessage: 'Закрепленное сообщение',
    emptyStateText: 'Задайте вопрос, чтобы начать общение с SenterosAI',
    copy: 'Копировать',
    like: 'Нравится',
    dislike: 'Не нравится',
    regenerate: 'Сгенерировать заново',
    deleteChat: 'Удалить этот чат?',
    confirmDelete: 'Подтвердить удаление',
    editChatName: 'Изменить название',
    comingSoon: 'Скоро будет',
    featureComingSoon: 'Эта функция появится в ближайшем обновлении!'
  },
  en: {
    newChat: 'New chat',
    askPlaceholder: 'Ask SenterosAI...',
    chatHistory: 'Chat history',
    settings: 'Settings',
    theme: 'Theme',
    darkTheme: 'Dark',
    lightTheme: 'Light',
    language: 'Language',
    rename: 'Rename chat',
    cancel: 'Cancel',
    save: 'Save',
    pinnedMessage: 'Pinned message',
    emptyStateText: 'Ask a question to start chatting with SenterosAI',
    copy: 'Copy',
    like: 'Like',
    dislike: 'Dislike',
    regenerate: 'Regenerate response',
    deleteChat: 'Delete this chat?',
    confirmDelete: 'Confirm deletion',
    editChatName: 'Edit chat name',
    comingSoon: 'Coming Soon',
    featureComingSoon: 'This feature will be available in an upcoming update!'
  }
};

// Get translation based on language and key
export const getTranslation = (language: string, key: string): string => {
  const lang = language === 'en' ? 'en' : 'ru'; // Default to ru if not en
  return translations[lang][key as keyof typeof translations[typeof lang]] || key;
};

import { SYSTEM_PROMPT, SYSTEM_PROMPT_EN, FEW_SHOT_EXAMPLES_RU, FEW_SHOT_EXAMPLES_EN } from './aiPrompts';

// System message based on language
export const getSystemMessage = (language: string): string => {
  if (language === 'en') {
    return SYSTEM_PROMPT_EN;
  }
  
  return SYSTEM_PROMPT;
};

// Get few-shot examples based on language
export const getFewShotExamples = (language: string): Array<{user: string, assistant: string}> => {
  if (language === 'en') {
    return FEW_SHOT_EXAMPLES_EN;
  }
  
  return FEW_SHOT_EXAMPLES_RU;
};
