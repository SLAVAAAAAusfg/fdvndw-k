import { apiRequest } from "@/lib/queryClient";
import { MessageType, ChatType, SettingsType } from "@shared/schema";
import { getSystemMessage, getFewShotExamples } from "./languageUtils";

// Get all chats
export async function getChats(): Promise<ChatType[]> {
  const response = await apiRequest("GET", "/api/chats");
  return await response.json();
}

// Get chat by id with messages
export async function getChatById(id: string): Promise<ChatType> {
  const response = await apiRequest("GET", `/api/chats/${id}`);
  return await response.json();
}

// Create a new chat
export async function createChat(name: string): Promise<ChatType> {
  const response = await apiRequest("POST", "/api/chats", { name });
  return await response.json();
}

// Update chat (rename or set pinned message)
export async function updateChat(id: string, data: { name?: string, pinnedMessageId?: string | null }): Promise<ChatType> {
  const response = await apiRequest("PATCH", `/api/chats/${id}`, data);
  return await response.json();
}

// Delete a chat
export async function deleteChat(id: string): Promise<void> {
  await apiRequest("DELETE", `/api/chats/${id}`);
}

// Create a new message
export async function createMessage(chatId: string, role: string, content: string): Promise<MessageType> {
  const response = await apiRequest("POST", "/api/messages", { 
    chatId: parseInt(chatId),
    role,
    content 
  });
  return await response.json();
}

// Get settings
export async function getSettings(): Promise<SettingsType> {
  const response = await apiRequest("GET", "/api/settings");
  return await response.json();
}

// Update settings
export async function updateSettings(settings: Partial<SettingsType>): Promise<SettingsType> {
  const response = await apiRequest("PATCH", "/api/settings", settings);
  return await response.json();
}

// Get AI completion
export async function getAICompletion(
  message: string, 
  language: string, 
  previousMessages: MessageType[] = [],
  hasImage: boolean = false
): Promise<string> {
  const systemMessage = getSystemMessage(language);
  
  // Получаем примеры few-shot для текущего языка
  const fewShotExamples = getFewShotExamples(language);
  
  // Форматируем предыдущие сообщения для отправки на сервер
  // Ограничим количество сообщений до 15, чтобы не превысить лимит контекста
  // Берем последние 15 сообщений, если их больше
  const messagesToSend = previousMessages.length > 15 ? previousMessages.slice(-15) : previousMessages;
  
  console.log("Отправляем сообщения в контексте:", messagesToSend.length);
  const formattedPreviousMessages = messagesToSend.map(msg => ({
    role: msg.role,
    content: msg.content
  }));
  
  const response = await apiRequest("POST", "/api/ai/complete", {
    message,
    systemMessage,
    previousMessages: formattedPreviousMessages,
    fewShotExamples,
    hasImage: hasImage,
    model: hasImage ? 'gpt-4o' : 'gpt-4o-mini' // Используем полную версию GPT-4o для изображений
  });
  
  const data = await response.json();
  return data.response;
}
