import React from 'react';
import { marked } from 'marked';
import DOMPurify from 'dompurify';

// Safely sanitize HTML
export function sanitizeHtml(html: string): string {
  return DOMPurify.sanitize(html, {
    ALLOWED_TAGS: [
      'a', 'b', 'blockquote', 'br', 'code', 'em', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'hr', 'i', 'img', 'li', 'ol', 'p', 'pre', 's', 'span', 'strong', 'table',
      'tbody', 'td', 'th', 'thead', 'tr', 'u', 'ul'
    ],
    ALLOWED_ATTR: [
      'href', 'target', 'rel', 'src', 'alt', 'class', 'style'
    ],
    ALLOWED_URI_REGEXP: /^(https?|mailto):/i,
    ADD_ATTR: ['target'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick'],
    ADD_URI_SAFE_ATTR: ['src'],
    FORBID_TAGS: ['script', 'style', 'iframe'],
    ALLOW_ARIA_ATTR: true
  });
}

// Helper function to apply syntax highlighting
function applySyntaxHighlighting(code: string): string {
  return code
    .replace(/\b(const|let|var|function|return|if|else|for|while|class|import|export|from|new|this|async|await)\b/g, '<span class="keyword">$1</span>')
    .replace(/(".*?"|'.*?'|`.*?`)/g, '<span class="string">$1</span>')
    .replace(/\b(\d+)\b/g, '<span class="number">$1</span>')
    .replace(/\b([a-zA-Z]+)\(/g, '<span class="function">$1</span>(')
    .replace(/(\/\/.*$)/gm, '<span class="comment">$1</span>')
    .replace(/(&lt;\/?\w+)/g, '<span class="tag">$1</span>')
    .replace(/(\w+)=/g, '<span class="attr-name">$1</span>=')
    .replace(/=(".*?"|'.*?')/g, '=<span class="attr-value">$1</span>')
    .replace(/(\+|\-|\*|\/|\=|\?|\:|\.|&lt;|&gt;)/g, '<span class="operator">$1</span>')
    .replace(/(\(|\)|\{|\}|\[|\]|\;|\,)/g, '<span class="punctuation">$1</span>');
}

// Setup marked before using
function setupMarked() {
  // Configure marked options
  marked.setOptions({
    breaks: true,
    gfm: true,
  });
  
  // Replace the renderer function to avoid LSP issues
  const renderer = new marked.Renderer();
  
  // Original renderer code function
  const originalCodeRenderer = renderer.code.bind(renderer);
  
  // Override code renderer
  renderer.code = function(code, language) {
    const highlighted = applySyntaxHighlighting(code);
    return `<pre><code class="language-${language || 'text'}">${highlighted}</code></pre>`;
  };
  
  marked.use({ renderer });
}

// Component that renders markdown with proper sanitization
export function MarkdownContent({ content }: { content: string }) {
  try {
    // Setup marked with proper renderer
    setupMarked();
    
    // Parse markdown to HTML and handle potential Promise
    let htmlContent = '';
    try {
      const parsedContent = marked.parse(content);
      htmlContent = typeof parsedContent === 'string' ? parsedContent : '';
    } catch (parseError) {
      console.error('Error parsing markdown:', parseError);
      htmlContent = content;
    }
    
    // Sanitize HTML to prevent XSS attacks
    const sanitizedHtml = sanitizeHtml(htmlContent);
    
    return (
      <div 
        className="markdown-content"
        dangerouslySetInnerHTML={{ __html: sanitizedHtml }} 
      />
    );
  } catch (error) {
    console.error('Error rendering markdown:', error);
    return <div className="markdown-content">{content}</div>;
  }
}

// Simple function to render markdown as HTML string
export function renderMarkdown(markdown: string): string {
  try {
    // Setup marked with proper renderer
    setupMarked();
    
    // Convert markdown to HTML and handle potential Promise
    let htmlContent = '';
    try {
      const parsedContent = marked.parse(markdown);
      htmlContent = typeof parsedContent === 'string' ? parsedContent : '';
    } catch (parseError) {
      console.error('Error parsing markdown:', parseError);
      htmlContent = markdown;
    }
    
    // Return sanitized HTML
    return sanitizeHtml(htmlContent);
  } catch (error) {
    console.error('Error rendering markdown:', error);
    return markdown;
  }
}