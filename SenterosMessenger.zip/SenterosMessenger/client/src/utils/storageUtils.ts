import { ChatType, MessageType, SettingsType } from "@shared/schema";

// Local storage keys
const STORAGE_KEYS = {
  CHATS: 'senterosAI_chats',
  CURRENT_CHAT_ID: 'senterosAI_currentChatId',
  SETTINGS: 'senterosAI_settings'
};

// Save chats to local storage
export const saveChats = (chats: ChatType[], currentChatId?: string): void => {
  localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(chats));
  if (currentChatId) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_CHAT_ID, currentChatId);
  }
};

// Load chats from local storage
export const loadChats = (): { chats: ChatType[], currentChatId: string | null } => {
  const chatsJson = localStorage.getItem(STORAGE_KEYS.CHATS);
  const currentChatId = localStorage.getItem(STORAGE_KEYS.CURRENT_CHAT_ID);
  
  return {
    chats: chatsJson ? JSON.parse(chatsJson) : [],
    currentChatId
  };
};

// Save settings to local storage
export const saveSettings = (settings: SettingsType): void => {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
};

// Load settings from local storage
export const loadSettings = (): SettingsType => {
  const settingsJson = localStorage.getItem(STORAGE_KEYS.SETTINGS);
  const defaultSettings: SettingsType = { language: 'ru', theme: 'dark' };
  
  if (!settingsJson) return defaultSettings;
  
  try {
    return { ...defaultSettings, ...JSON.parse(settingsJson) };
  } catch (e) {
    return defaultSettings;
  }
};

// Create a new chat in memory
export const createChatInMemory = (name: string = "Новый чат"): ChatType => {
  return {
    id: Date.now().toString(),
    name,
    messages: [],
    pinnedMessageId: null
  };
};

// Create a new message in memory
export const createMessageInMemory = (role: string, content: string): MessageType => {
  return {
    id: Date.now().toString(),
    role,
    content,
    timestamp: Date.now()
  };
};
