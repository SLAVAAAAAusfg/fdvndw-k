import React, { useState, useEffect, useRef } from 'react';
import ChatHeader from '../components/ChatHeader';
import ChatSidebar from '../components/ChatSidebar';
import ChatMessages from '../components/ChatMessages';
import ChatInput from '../components/ChatInput';
import ChatSettings from '../components/ChatSettings';
import RenameModal from '../components/RenameModal';
import { ChatType, MessageType, SettingsType } from '@shared/schema';
import { loadChats, loadSettings, saveChats, saveSettings, createChatInMemory, createMessageInMemory } from '../utils/storageUtils';
import { getAICompletion } from '../utils/apiUtils';
import { useToast } from '@/hooks/use-toast';

const ChatPage: React.FC = () => {
  // State
  const [chats, setChats] = useState<ChatType[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [settings, setSettings] = useState<SettingsType>({ language: 'ru', theme: 'dark' });
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isRenameModalOpen, setIsRenameModalOpen] = useState<boolean>(false);
  const [chatToRename, setChatToRename] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  const sidebarRef = useRef<HTMLDivElement>(null);
  const settingsRef = useRef<HTMLDivElement>(null);
  
  const { toast } = useToast();

  // Handle click outside to close sidebar and settings
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // Если кликнуто не внутри меню и не по кнопке меню
      const button = document.querySelector("[aria-label='Toggle sidebar']");
      const settingsButton = document.querySelector("[aria-label='Toggle settings']");
      
      // Для сайдбара
      if (
        sidebarRef.current && 
        !sidebarRef.current.contains(event.target as Node) && 
        button !== event.target &&
        !(button?.contains(event.target as Node))
      ) {
        setIsSidebarOpen(false);
      }
      
      // Для панели настроек
      if (
        settingsRef.current && 
        !settingsRef.current.contains(event.target as Node) && 
        settingsButton !== event.target &&
        !(settingsButton?.contains(event.target as Node))
      ) {
        setIsSettingsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Initialize data
  useEffect(() => {
    const { chats: savedChats, currentChatId: savedChatId } = loadChats();
    const savedSettings = loadSettings();
    
    // If no chats exist, create default one
    if (savedChats.length === 0) {
      const defaultChat = createChatInMemory('SenterosAI');
      
      // Add welcome message
      const welcomeMessage: MessageType = createMessageInMemory(
        'assistant',
        settings.language === 'en' 
          ? 'Hello! How are you? ^^ How can I help you today? ✨'
          : 'Привет! Как дела? ^^ Чем могу помочь сегодня? ✨'
      );
      
      defaultChat.messages.push(welcomeMessage);
      
      setChats([defaultChat]);
      setCurrentChatId(defaultChat.id);
      saveChats([defaultChat], defaultChat.id);
    } else {
      setChats(savedChats);
      setCurrentChatId(savedChatId || savedChats[0].id);
    }
    
    setSettings(savedSettings);
  }, []);

  // Current chat object
  const currentChat = chats.find(chat => chat.id === currentChatId) || null;
  
  // Get pinned message
  const pinnedMessage = currentChat?.pinnedMessageId 
    ? currentChat.messages.find(msg => msg.id === currentChat.pinnedMessageId) 
    : null;

  // Toggle sidebar
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Toggle settings
  const toggleSettings = () => {
    setIsSettingsOpen(!isSettingsOpen);
  };

  // Create new chat
  const createNewChat = () => {
    const newChat = createChatInMemory(
      settings.language === 'en' ? 'New chat' : 'Новый чат'
    );
    
    const updatedChats = [...chats, newChat];
    setChats(updatedChats);
    setCurrentChatId(newChat.id);
    saveChats(updatedChats, newChat.id);
    
    // Close sidebar on mobile
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  // Change active chat
  const changeChat = (chatId: string) => {
    setCurrentChatId(chatId);
    saveChats(chats, chatId);
    
    // Close sidebar on mobile
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  // Rename chat
  const openRenameModal = (chatId: string) => {
    setChatToRename(chatId);
    setIsRenameModalOpen(true);
  };

  const renameChat = (chatId: string, newName: string) => {
    const updatedChats = chats.map(chat => 
      chat.id === chatId ? { ...chat, name: newName } : chat
    );
    
    setChats(updatedChats);
    saveChats(updatedChats, currentChatId || undefined);
    setIsRenameModalOpen(false);
  };

  // Delete chat
  const deleteChat = (chatId: string) => {
    const updatedChats = chats.filter(chat => chat.id !== chatId);
    
    // If we're deleting the current chat, switch to another one
    if (chatId === currentChatId) {
      if (updatedChats.length > 0) {
        setCurrentChatId(updatedChats[0].id);
        saveChats(updatedChats, updatedChats[0].id);
      } else {
        // Create a new chat if we deleted the last one
        const newChat = createChatInMemory(
          settings.language === 'en' ? 'New chat' : 'Новый чат'
        );
        setChats([newChat]);
        setCurrentChatId(newChat.id);
        saveChats([newChat], newChat.id);
      }
    } else {
      setChats(updatedChats);
      saveChats(updatedChats, currentChatId || undefined);
    }
  };

  // Send message
  const sendMessage = async (content: string, imageUrl?: string) => {
    if (!currentChatId || (!content.trim() && !imageUrl)) return;
    
    // Create user message with optional image
    const userMessage: MessageType = {
      ...createMessageInMemory('user', content),
      imageUrl
    };
    
    // Update current chat with the new message
    const updatedChats = chats.map(chat => {
      if (chat.id === currentChatId) {
        return {
          ...chat,
          messages: [...chat.messages, userMessage]
        };
      }
      return chat;
    });
    
    setChats(updatedChats);
    saveChats(updatedChats, currentChatId);
    
    // Create a prompt that includes reference to the image if present
    const promptWithImageContext = imageUrl 
      ? `${content || ''}\n\n[Примечание: пользователь прикрепил изображение]` 
      : content;
    
    // Get AI response
    await getAIResponseForLastMessage(updatedChats, currentChatId, promptWithImageContext, !!imageUrl);
  };

  // Helper function to get AI response
  const getAIResponseForLastMessage = async (
    updatedChats: ChatType[], 
    chatId: string, 
    prompt: string,
    hasImage: boolean = false
  ) => {
    if (!chatId) return;
    
    setIsLoading(true);
    
    try {
      // Найдем текущий чат
      const currentChat = updatedChats.find(chat => chat.id === chatId);
      if (!currentChat) return;
      
      // Соберем все предыдущие сообщения для полного контекста
      // Возьмем все сообщения, чтобы сохранить полный контекст беседы
      const contextMessages = currentChat.messages
        .slice(0, -1);  // Берем все сообщения кроме последнего (оно уже передано как prompt)
      
      console.log("Предыдущие сообщения для контекста:", contextMessages.length);
      
      // Get AI response from API с учетом контекста и модели
      const aiResponse = await getAICompletion(prompt, settings.language, contextMessages, hasImage);
      
      // Create AI message
      const aiMessage: MessageType = createMessageInMemory('assistant', aiResponse);
      
      // Update chat with AI response
      const finalChats = updatedChats.map(chat => {
        if (chat.id === chatId) {
          return {
            ...chat,
            messages: [...chat.messages, aiMessage]
          };
        }
        return chat;
      });
      
      setChats(finalChats);
      saveChats(finalChats, chatId);
    } catch (error) {
      console.error('Error getting AI response:', error);
      toast({
        title: "Error",
        description: settings.language === 'en' 
          ? "Failed to get response from AI" 
          : "Не удалось получить ответ от ИИ",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Pin/unpin message
  const togglePinMessage = (messageId: string) => {
    if (!currentChatId) return;
    
    const updatedChats = chats.map(chat => {
      if (chat.id === currentChatId) {
        // Toggle pin status
        const newPinnedId = chat.pinnedMessageId === messageId ? null : messageId;
        return {
          ...chat,
          pinnedMessageId: newPinnedId
        };
      }
      return chat;
    });
    
    setChats(updatedChats);
    saveChats(updatedChats, currentChatId);
  };
  
  // Regenerate AI response
  const regenerateResponse = async (messageId: string) => {
    if (!currentChatId || !currentChat) return;
    
    // Find the AI message and the user message before it
    const messageIndex = currentChat.messages.findIndex(m => m.id === messageId);
    if (messageIndex <= 0 || currentChat.messages[messageIndex].role !== 'assistant') {
      // Not an AI message or no user message before it
      return;
    }
    
    // Get the user message before this AI message
    const userMessage = currentChat.messages[messageIndex - 1];
    if (userMessage.role !== 'user') {
      // No user message before this AI message
      return;
    }
    
    // Remove the AI message
    const updatedMessages = [...currentChat.messages];
    updatedMessages.splice(messageIndex, 1);
    
    // Update the chat without the AI message
    const updatedChats = chats.map(chat => {
      if (chat.id === currentChatId) {
        return {
          ...chat,
          messages: updatedMessages
        };
      }
      return chat;
    });
    
    setChats(updatedChats);
    
    // Generate a new response to the user message
    // Проверяем, есть ли у сообщения изображение
    const hasImage = !!userMessage.imageUrl;
    await getAIResponseForLastMessage(updatedChats, currentChatId, userMessage.content, hasImage);
  };

  // Update settings
  const updateSettings = (newSettings: SettingsType) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  return (
    <div className="bg-background text-foreground min-h-screen flex flex-col">
      <ChatHeader 
        currentChat={currentChat}
        chats={chats}
        toggleSidebar={toggleSidebar}
        toggleSettings={toggleSettings}
        createNewChat={createNewChat}
        onChangeChat={changeChat}
        onRenameChat={openRenameModal}
        onDeleteChat={deleteChat}
        language={settings.language}
      />
      
      <div className="flex flex-1 relative overflow-hidden w-full">
        {/* Backdrop for sidebar */}
        {isSidebarOpen && (
          <div className="modal-backdrop md:hidden" />
        )}

        {/* Sidebar with ref for click outside detection */}
        <div ref={sidebarRef}>
          <ChatSidebar 
            chats={chats}
            currentChatId={currentChatId}
            isOpen={isSidebarOpen}
            language={settings.language}
            onCreateChat={createNewChat}
            onChangeChat={changeChat}
            onRenameChat={openRenameModal}
            onDeleteChat={deleteChat}
          />
        </div>
        
        <main className="flex-1 flex flex-col max-h-[calc(100vh-56px)] w-full relative">
          <ChatMessages 
            chat={currentChat}
            pinnedMessage={pinnedMessage}
            language={settings.language}
            onPinMessage={togglePinMessage}
            onRegenerateResponse={regenerateResponse}
          />
          
          <ChatInput 
            onSendMessage={sendMessage}
            language={settings.language}
            isLoading={isLoading}
          />
        </main>
        
        {/* Backdrop for settings */}
        {isSettingsOpen && (
          <div className="modal-backdrop md:hidden" />
        )}

        {/* Settings with ref for click outside detection */}
        <div ref={settingsRef}>
          <ChatSettings 
            isOpen={isSettingsOpen}
            settings={settings}
            onClose={toggleSettings}
            onUpdateSettings={updateSettings}
          />
        </div>
      </div>
      
      {isRenameModalOpen && (
        <RenameModal 
          chatId={chatToRename || ''}
          initialName={chatToRename ? chats.find(c => c.id === chatToRename)?.name || '' : ''}
          isOpen={isRenameModalOpen}
          language={settings.language}
          onClose={() => setIsRenameModalOpen(false)}
          onRename={renameChat}
        />
      )}
    </div>
  );
};

export default ChatPage;
